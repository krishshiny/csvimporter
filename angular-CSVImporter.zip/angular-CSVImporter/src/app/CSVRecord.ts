export class CSVRecord {
    public firstName: String;  
    public sureName: String;
    public issueCount: String;
    public dateofbirth: String;
}