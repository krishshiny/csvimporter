package com.robobank.customer;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLParser {

	
	public static List<Records> getCustomerXMLRecords() {
		List<Records> recordsList = new ArrayList<>();
		try {
			File inputFile = new File("C:/Customer/records.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("record");
			System.out.println("----------------------------");
			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Records records = new Records();
				Node nNode = nList.item(temp);
				System.out.println("\nCurrent Element :" + nNode.getNodeName());

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					System.out.println("reference no : " + eElement.getAttribute("reference"));
					records.setReference(eElement.getAttribute("reference"));
					System.out.println(
							"accountNumber: " + eElement.getElementsByTagName("accountNumber").item(0).getTextContent());
					records.setAccountNumber(eElement.getElementsByTagName("accountNumber").item(0).getTextContent());
					System.out.println(
							"description: " + eElement.getElementsByTagName("description").item(0).getTextContent());
					records.setDescription(eElement.getElementsByTagName("description").item(0).getTextContent());
					System.out.println(
							"startBalance : " + eElement.getElementsByTagName("startBalance").item(0).getTextContent());
					records.setStartBalance(Double.parseDouble(eElement.getElementsByTagName("startBalance").item(0).getTextContent()));
					System.out.println(
							"mutation: " + eElement.getElementsByTagName("mutation").item(0).getTextContent());
					records.setMutation(Double.parseDouble(eElement.getElementsByTagName("mutation").item(0).getTextContent()));
					System.out.println("endBalance : " + eElement.getElementsByTagName("endBalance").item(0).getTextContent());
					records.setEndBalance(Double.parseDouble(eElement.getElementsByTagName("endBalance").item(0).getTextContent()));
					recordsList.add(records);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return recordsList;
	}
}
