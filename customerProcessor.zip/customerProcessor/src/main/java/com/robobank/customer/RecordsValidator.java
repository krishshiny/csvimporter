package com.robobank.customer;

import java.util.List;

public class RecordsValidator {

	public static boolean xmlRecordValidator(List<Records> customeXMLRecords) {
		boolean status = false;
		
		
		return status;
	}
	
	
	public static boolean csvRecordValidator(List<Records> customeCSVRecords) {
		boolean status = false;
		
		return status;
	}
	
}
