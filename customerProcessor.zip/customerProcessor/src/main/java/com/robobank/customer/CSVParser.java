package com.robobank.customer;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CSVParser {

	public static List<Records> parseCSVRecords() throws IOException {
		String line = "";
		String splitBy = ",";
		// parsing a CSV file into BufferedReader class constructor
		List<Records> recordsList = new ArrayList<>();
		BufferedReader br = new BufferedReader(new FileReader("C:/Customer/records.csv"));
		try {

			while ((line = br.readLine()) != null) // returns a Boolean value
			{
				Records record = new Records();
				String[] records = line.split(splitBy); // use comma as separator
				System.out.println("Records [Reference=" + records[0] + ", AccountNumber=" + records[1]
						+ ", Description	=" + records[2] + ", startBalance=" + records[3] + ", Mutation= "
						+ records[4] + ", endBalance= " + records[5] + "]");
				record.setAccountNumber(records[1]);
				record.setReference(records[0]);
				record.setDescription(records[2]);
				record.setStartBalance(Double.parseDouble(records[3]));
				record.setEndBalance(Double.parseDouble(records[5]));
				record.setMutation(Double.parseDouble(records[4]));
				recordsList.add(record);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			br.close();
		}
		return recordsList;
	}

}
