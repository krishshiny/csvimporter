package com.robobank.customer;

import java.io.IOException;
import java.util.List;



public class CustomerApplication {

	public static void main(String argv[]) throws IOException {

		List<Records> customeXMLRecords = XMLParser.getCustomerXMLRecords();
		
		List<Records> customeCSVRecords = CSVParser.parseCSVRecords();
	}

}
